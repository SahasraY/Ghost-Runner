var tower,TImage,ghost,GImage,door,DImage,climber,CImage,invisible;
var PLAY=1
var END=0
var gameState=PLAY;
var invisibleGroup,climberGroup




function preload(){
TImage=loadImage("tower.png");
GImage=loadImage("ghost-jumping.png");
DImage=loadImage("door.png");
CImage=loadImage("climber.png");

}
function setup(){
createCanvas(400,400);
tower=createSprite(200,200,200,200); 
tower.addImage(TImage);
tower.velocityY=7;  
tower.scale=1;
  
ghost=createSprite(50,20,20,20);  
ghost.addImage(GImage);
ghost.scale=0.3;
  
invisibleGroup=new Group();
climberGroup=new Group();
}
function draw(){
  background("white");
  
  if(gameState===PLAY){
  if(tower.y>400){
   tower.y=200; 
  }
  if(keyDown("space")){
    ghost.velocityY=-5;
  }
  ghost.velocityY=ghost.velocityY+0.5;
 
   if(keyDown("right")){
    ghost.x=ghost.x+5;
  }
  if(keyDown("left")){
    ghost.x=ghost.x-5;
  }
    spawndoors();
    if(ghost.y>400||ghost.isTouching(invisibleGroup)){
     gameState=END; 
    }
    if(ghost.isTouching(climberGroup)){
      ghost.velocityY=0;
    }
  }
  if(gameState===END){
    //tower.velocityY=0;
    fill("black")
    textSize(15);
    text("GAME OVER!",200,200);
    
  }
  
 
  drawSprites(); 
 
}
function spawndoors(){
if (frameCount % 180===0){
  door=createSprite(Math.round(random(30,370)),0,20,20);
  door.addImage(DImage);
  door.velocityY=3;
  door.scale=1;
  climber=createSprite(door.x,60,20,20);
  climber.addImage(CImage);
  climber.velocityY=3;
  climber.scale=1;
  
  invisible=createSprite(door.x,72,60,20);
  invisible.velocityY=3;
  invisible.visible=false;
  
  ghost.depth=door.depth+1;
  
  invisibleGroup.add(invisible);
climberGroup.add(climber);
  }

}